######################################DATA SET 1 CLEAN##########################
library(car)
library(tidyverse)
library(mice)
library(readxl)
library(dplyr)
library(estimatr)
install.packages('reticulate')
library(reticulate)
library(glmnet)
use_python('C:\\Users\\ltic\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Python 3.8\\Python 3.8 (32-bit).exe')
sns <-import("seaborn as SNS")
plt <- import('matplotlib.pyplot')
pd <- import('pandas')
library(pracma)

home.train<-read.csv(file.choose())
home.data.testing<-read.csv(file.choose())
home.data.full<-read.csv(file.choose())

head(home.train)
str(home.train)
head(home.train, 4) #show the first 4 rows in the home.data dataframe
tail(home.train,4) #show the last 4 rows in the home.data dataframe
summary(home.train)

#############################MICE#############################
md.pattern(home.train)
imputed_data <- mice(home.train, m=1, maxit=500, meth='cart', seed=500)

completed_data <- complete(imputed_data, 1)
summary(completed_data)
md.pattern(completed_data)

home.data.testing<-subset(completed_data, (ID>=876 & ID<=1460)) 
home.data.training<-subset(completed_data, ID<=875) 

str(home.data.training)

write.csv(completed_data, file = "Fulldata.csv")

##########################Firstlook########################################
fit<- lm(SalePrice ~ ., data=home.data.training)
summary(fit)


