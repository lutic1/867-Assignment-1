# -*- coding: utf-8 -*-
"""
Created on Tue Apr 28 23:11:56 2020

@author: ltic
"""
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
%matplotlib inline
train_df = pd.read_csv('Clean_set1.csv')

train_df=train_df.drop(['Id'],axis=1)
train_df.head()



corrmat =train_df.corr()
f, ax = plt.subplots(figsize=(25, 10))
sns.heatmap(corrmat, vmax=0.8, square=True)

"We found some variables that we could look at such as:
    "overall quality, year built, total bastmentsf, 1stfloor, General living area
    "Full bath, Total rooms above grade, garage cars, garage area" 

"now finding the top 10 correlated variables we can put the following:
    

k  = 10 
cols = corrmat.nlargest(k, 'SalePrice')['SalePrice'].index
cm = np.corrcoef(train_df[cols].values.T)
sns.set(font_scale=1.00)
hm = sns.heatmap(cm, cbar=True, annot=True, \
                 square=True, fmt='.2f', annot_kws={'size': 9}, yticklabels=cols.values, xticklabels=cols.values)
plt.show()