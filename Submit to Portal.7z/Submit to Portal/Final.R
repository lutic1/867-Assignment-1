library(pracma)
library(glmnet)
#############################################################files########
all<-read.csv(file.choose())
home.data.predict<-read.csv(file.choose())
home.data.training<-read.csv(file.choose())

home.data.training$SalePrice <- as.numeric(as.character(home.data.training$SalePrice))
all$SalePrice<- as.numeric(as.character(all$SalePrice))

home.data.testing.i<-subset(home.data.training, (ID>=947 & ID<=1460)) 
home.data.training.i<-subset(home.data.training, ID<=946)

##############################Linears testing identified##################################
fit1<- lm(log(SalePrice)~log(LotArea)+OverallQual+GrLivArea+GarageCars+X1stFlrSF+FullBath+TotRmsAbvGrd+YearBuilt, data=home.data.training.i)
summary(fit1)


predicted.prices.testing.i<-exp(predict(fit1,home.data.testing.i))
percent.errors.i <- abs((home.data.testing.i$SalePrice-predicted.prices.testing.i)/home.data.testing.i$SalePrice)*100
mean(percent.errors.i)
###12.97######

###########################################################################################################
fit2<-lm(log(SalePrice)~log(LotArea)+OverallQual+GrLivArea+MSZoning+Utilities+LotConfig+Neighborhood+Condition1+OverallCond+YearBuilt+YearRemodAdd+FullBath+BsmtExposure+BsmtFinSF1+BsmtFinSF2+BsmtUnfSF+X1stFlrSF+X2ndFlrSF+KitchenQual+FunctioNonel,data=home.data.training.i) 
summary(fit2)         

predicted.prices.testing2<-exp(predict(fit2, home.data.testing.i))
percent.errors.ii <- abs((home.data.testing.i$SalePrice-predicted.prices.testing2)/home.data.testing.i$SalePrice)*100
mean(percent.errors.ii)
###11.10###

###########################################################################################################
fit3<-lm(log(SalePrice)~log(LotArea)*GrLivArea+Neighborhood+OverallQual+Utilities+LotConfig+Neighborhood+Condition1+OverallCond+YearBuilt+YearRemodAdd+FullBath+BsmtExposure+BsmtUnfSF+X1stFlrSF+KitchenQual,data=home.data.training.i) 
summary(fit3)         

predicted.prices.testing3<-exp(predict(fit3, home.data.testing.i))
percent.errors.ii <- abs((home.data.testing.i$SalePrice-predicted.prices.testing3)/home.data.testing.i$SalePrice)*100
mean(percent.errors.ii)
###10.07###
##########################################Lasso##########################

y<-log(home.data.training.i$SalePrice)
X<-model.matrix(ID~log(LotArea)*MSZoning*log(GrLivArea)+BsmtExposure*YearBuilt+YearBuilt*YearRemodAdd*Neighborhood+GrLivArea*Utilities*OverallQual+OverallQual*GrLivArea+Utilities+nthroot(OverallCond,3)+BsmtExposure*YearRemodAdd+YearBuilt*Neighborhood+YearRemodAdd*OverallQual+GrLivArea*Utilities*GrLivArea*Utilities+OverallQual*LotConfig+nthroot(FullBath,3)+BsmtExposure+OverallQual+YearBuilt+OverallQual+YearRemodAdd*GrLivArea*Utilities+GrLivArea*Utilities*LotConfig+OverallQual+Neighborhood+nthroot(BsmtUnfSF,3)+BsmtExposure*GrLivArea*Utilities+YearBuilt*GrLivArea*Utilities+YearRemodAdd+LotConfig+GrLivArea*+Utilities*Neighborhood+OverallQual*Condition1+nthroot(X1stFlrSF,3)+BsmtExposure+LotConfig+YearBuilt+LotConfig+YearRemodAdd*Condition1+GrLivArea*Utilities*Condition1+OverallQual+KitchenQual++BsmtExposure*Neighborhood+YearBuilt*Condition1+YearRemodAdd+KitchenQual+GrLivArea*Utilities+KitchenQual++BsmtExposure+Condition1+YearBuilt+KitchenQual+nthroot(GrLivArea,3)+BsmtExposure*YearBuilt+YearBuilt*YearRemodAdd+YearRemodAdd+Neighborhood+GrLivArea*Utilities*OverallQual+OverallQual*GrLivArea+Utilities+BsmtExposure*KitchenQual+nthroot(OverallCond,3)+BsmtExposure*YearRemodAdd+YearBuilt*Neighborhood+YearRemodAdd*OverallQual+GrLivArea*Utilities*GrLivArea*Utilities+OverallQual*LotConfig+nthroot(FullBath,3)+BsmtExposure+OverallQual+YearBuilt+OverallQual+YearRemodAdd*GrLivArea*Utilities+GrLivArea*Utilities*LotConfig+OverallQual+Neighborhood+nthroot(BsmtUnfSF,3)+BsmtExposure*GrLivArea*Utilities+YearBuilt*GrLivArea*Utilities+YearRemodAdd+LotConfig+GrLivArea*+Utilities*Neighborhood+OverallQual*Condition1+nthroot(X1stFlrSF,3)+BsmtExposure+LotConfig+YearBuilt+LotConfig+YearRemodAdd*Condition1+GrLivArea*Utilities*Condition1+OverallQual+KitchenQual++BsmtExposure*Neighborhood+YearBuilt*Condition1+YearRemodAdd+KitchenQual+GrLivArea*Utilities+KitchenQual++BsmtExposure+Condition1+YearBuilt+KitchenQual+nthroot(GrLivArea,3)+BsmtExposure*YearBuilt+YearBuilt*YearRemodAdd+YearRemodAdd+Neighborhood+GrLivArea*Utilities*OverallQual+OverallQual*GrLivArea+Utilities+BsmtExposure*KitchenQual+nthroot(GrLivArea,3)+sqrt(GrLivArea)+log(GrLivArea)+nthroot(OverallCond,3)+BsmtExposure*YearRemodAdd+YearBuilt*Neighborhood+YearRemodAdd*OverallQual+GrLivArea*Utilities*GrLivArea*Utilities+OverallQual*LotConfig+nthroot(OverallCond,3)+sqrt(OverallCond)+log(OverallCond), data=all)[,-1]
X<-cbind(all$ID,X)

X.training<-subset(X,X[,1]<=946)
X.testing<-subset(X, (X[,1]>=947 & X[,1]<=1460))
X.prediction<-subset(X,X[,1]>=1461)

#LASSO (alpha=1)
lasso.fit<-glmnet(x = X.training, y = y, alpha = 1)
plot(lasso.fit, xvar = "lambda")

crossval <-  cv.glmnet(x = X.training, y = y, alpha = 1) #create cross-validation data
plot(crossval)

penalty.lasso <- crossval$lambda.min #determine optimal penalty parameter, lambda
log(penalty.lasso)

lasso.opt.fit <-glmnet(x = X.training, y = y, alpha = 1, lambda = penalty.lasso) #estimate the model with the optimal penalty
coef(lasso.opt.fit) #resultant model coefficients

# predicting the performance on the testing set
lasso.testing <- exp(predict(lasso.opt.fit, s = penalty.lasso, newx =X.testing))
mean(abs(lasso.testing-home.data.testing.i$SalePrice)/home.data.testing.i$SalePrice*100)

predicted.prices.log.i.lasso <- exp(predict(lasso.opt.fit, s = penalty.lasso, newx =X.prediction))
write.csv(predicted.prices.log.i.lasso, file = "Final Predicted Home Prices LOG INTERACTION LASSO11.csv")

#####9.78####

